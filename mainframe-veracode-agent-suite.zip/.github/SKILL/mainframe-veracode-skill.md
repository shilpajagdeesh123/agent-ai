# Mainframe Veracode Skill

## Purpose

Define deterministic rules for analyzing and reporting mainframe Veracode findings.

## Universal Finding Support

Support every Veracode CWE, finding category, severity, status, source, sink, and metadata field. For unfamiliar findings, capture metadata, identify the violated security property, trace source-to-sink flow, identify missing controls, classify, recommend remediation, and include the finding in the CSV.

## Veracode API Handling

- Accept current and future API versions.
- Do not assume fixed endpoint or field names.
- Use semantic field mapping where possible.
- Preserve unknown fields in `Analysis Notes`.
- Never fail the full run because one record is malformed.

## Detailed Procedure

1. Extract application, scan, finding, CWE, severity, status, module, program, file, line, source, sink, data path, mitigation, recommendation, API version, schema version, and unknown metadata.
2. Locate the exact source statement.
3. Trace only relevant data paths, including MOVE, STRING, UNSTRING, INSPECT, REDEFINES, OCCURS, reference modification, copybooks, called programs, and returned fields.
4. Review allow-list, length, range, format, RACF, CICS, DB2, file, masking, control-character, and operational controls.
5. Evaluate reachability, input control, bypass possibilities, sink behavior, runtime privilege, dead code, and environmental controls.
6. Use the exact classification list defined by the agent.
7. Recommend minimal, compiler-compatible remediation that preserves interfaces, layouts, return codes, transaction flow, database behavior, and restartability.
8. Explain how the remediation breaks the tainted path and whether Veracode rescan is required.

## Mainframe Rules

### COBOL
Review MOVE, STRING, UNSTRING, INSPECT, REDEFINES, OCCURS, COMP, COMP-3, group moves, reference modification, truncation, and sign handling. Prefer explicit allow-list validation.

### DB2
Prefer static SQL, host variables, and parameter markers. Allow-list dynamic identifiers. Preserve SQLCODE, SQLSTATE, cursor, commit, and rollback behavior.

### CICS
Review COMMAREA, EIBCALEN, channels, containers, RECEIVE, SEND, LINK, XCTL, START, RETURN, temporary storage, transient data, RESP, and RESP2. Use fixed or allow-listed resource names.

### Logging and CRLF
Do not log raw untrusted values. Neutralize CR, LF, tab, escape, and non-printable controls. Avoid exposing secrets or complete sensitive records.

## CSV Validation

- Exact 42-column schema from the agent.
- One row per supplied finding.
- Unknown fields recorded as `Additional Veracode Metadata: field=value` in `Analysis Notes`.
- No unrelated findings.
- No silent omissions.
- Valid UTF-8 RFC 4180 CSV.
