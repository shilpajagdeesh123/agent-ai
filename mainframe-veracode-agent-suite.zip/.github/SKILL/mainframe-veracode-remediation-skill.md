# Mainframe Veracode Remediation Skill

## Purpose

Define deterministic rules for validating, designing, documenting, and generating safe remediation proposals for Critical and High mainframe Veracode findings.

## Input Rules

- Use the selected findings CSV as the only source of findings.
- Do not invent missing programs, files, lines, sources, sinks, or code.
- Preserve original Veracode metadata.
- Maintain one summary row per input finding.

## Source Validation Status

Use one:

- `Confirmed`
- `Changed Since Analysis`
- `Not Found`
- `Ambiguous`
- `Not Applicable`

Do not generate an automatic patch when source is `Not Found` or `Ambiguous`.

## Remediation Safety

Every remediation must fix the root cause and preserve business behavior, interfaces, copybook layouts, return codes, transaction boundaries, commit/rollback behavior, restartability, CICS/IMS/DB2/VSAM/MQ contracts, and compiler compatibility.

Never disable controls, add hardcoded secrets, suppress findings without a real control, or perform broad refactoring.

## Common Patterns

### SQL Injection
Use static SQL, host variables, or parameter markers. Never concatenate untrusted values into SQL. Allow-list identifiers that cannot be parameterized. Preserve SQLCODE, SQLSTATE, cursor, commit, and rollback behavior.

### CRLF and Log Injection
Remove or neutralize CR, LF, tab, escape, and non-printable controls. Prefer structured logging. Avoid logging complete sensitive values.

### Path and Resource Injection
Use fixed mappings or allow-lists for datasets, queues, transactions, programs, files, and commands. Reject separators, qualifiers, metacharacters, and control characters not explicitly allowed.

### Command Injection
Avoid command strings built from untrusted input. Use fixed templates and allow-listed arguments. Preserve return-code behavior.

### Bounds and Length Issues
Validate lengths before MOVE, STRING, UNSTRING, or reference modification. Validate OCCURS indexes. Respect PIC definitions and numeric formats.

### Authorization
Use approved RACF, CICS, DB2, IMS, or application authorization mechanisms before the sensitive operation. Preserve audit behavior.

### Sensitive Data Exposure
Mask sensitive fields, avoid full-value logging, use approved encryption/tokenization services, and never create custom cryptography.

## COBOL Rules

Match the compiler level and project conventions. Define new fields in the correct data division. Preserve copybook compatibility. Avoid unrelated edits.

## Patch Rules

- Unified diff format.
- Filename: `<PROGRAM>-<FINDING-ID>.patch`.
- Relevant changes only.
- No unrelated formatting.
- Preserve source layout and line endings where possible.
- Mark `Proposal Only` when business decisions are unresolved.

## Testing Rules

Define positive, negative, boundary, malformed-input, regression, authorization, SQL/transaction, restart, CICS/IMS, logging, and Veracode rescan tests as applicable.

## Output Validation

1. Every Critical and High finding has a summary row.
2. Every skipped finding has a reason.
3. Every patch has a report entry.
4. Patches reference confirmed source.
5. No source was modified directly.
6. No Medium or Low finding was processed unless requested.
7. No secrets or full sensitive records are exposed.
8. CSV is valid UTF-8.
9. Statuses use allowed values.
10. Same-day outputs are not overwritten.
11. Failures do not stop unrelated findings.
