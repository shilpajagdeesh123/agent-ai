# Remediation Output

Expected files: remediation report, summary CSV, execution log, and reviewable unified-diff patches. Application source must not be overwritten automatically.
