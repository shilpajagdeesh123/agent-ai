# Mainframe Veracode Output

The analysis agent writes dated findings CSV files here. The remediation agent reads the latest valid findings CSV and writes its artifacts under `remediation/`.
