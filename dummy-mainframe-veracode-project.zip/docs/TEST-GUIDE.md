# Test Guide

## Analysis Agent

Run:

```text
Execute the mainframe-veracode-agent for project DUMMY-MAINFRAME.
```

Expected behavior:

- Read the sample findings CSV
- Validate the COBOL, copybook, and JCL evidence
- Produce one analysis row per finding
- Preserve unknown or missing information in notes
- Avoid unrelated scanning

## Remediation Agent

Run:

```text
Execute the mainframe-veracode-remediation-agent for project DUMMY-MAINFRAME.
```

Expected default behavior:

- Process VF-1001 because it is Critical
- Process VF-1002 because it is High
- Review VF-1003 because it is High and marked Requires Manual Review
- Skip VF-1004 because it is Medium
- Skip VF-1005 because it is Low
- Generate remediation report, summary CSV, log, and reviewable patches
- Never directly overwrite source files

## Validation Checklist

- Critical and High filtering works
- CSV parsing works
- Source path resolution works
- Before/after code is generated
- SQL Injection remediation uses host variables or parameterization
- Log Injection remediation neutralizes control characters
- Dynamic CICS resource handling is reviewed safely
- Medium and Low findings are skipped by default
- Source files are not modified directly
