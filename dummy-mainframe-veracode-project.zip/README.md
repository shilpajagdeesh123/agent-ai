# Dummy Mainframe Veracode Project

This repository is intentionally vulnerable and is designed only for testing:

- `mainframe-veracode-agent`
- `mainframe-veracode-remediation-agent`

## Included Technologies

- COBOL
- DB2-style dynamic SQL
- CICS-style command construction
- Copybook usage
- JCL
- Logging

## Intentional Findings

1. Critical SQL Injection
2. High Log Injection / CRLF
3. High Resource Name Injection
4. Medium Sensitive Data Exposure
5. Low Hardcoded Operational Value

## Test Commands

```text
Execute the mainframe-veracode-agent for project DUMMY-MAINFRAME.
```

```text
Execute the mainframe-veracode-remediation-agent for project DUMMY-MAINFRAME.
```

## Important

This is not production code. It contains deliberate vulnerabilities for agent validation.
