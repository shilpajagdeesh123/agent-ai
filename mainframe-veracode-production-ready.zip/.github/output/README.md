# Output Directory

Generated reports will use this pattern:

`mainframe-veracode-agent-findings-<YYYY-MM-DD>.csv`
