
# Mainframe Veracode Enterprise Deliverable

This package scans COBOL and related mainframe source folders for potential Veracode-aligned security findings and supports safe remediation using GitHub Copilot Agent Mode.

## Included

- Windows batch source scanner with Veracode-style CSV output
- Production remediation agent
- Dedicated analysis and remediation skills
- Windows batch launchers
- PowerShell launcher
- Shell launcher
- Two multi-program COBOL applications
- Copybooks, JCL, and REXX utilities
- Sample generated findings
- Consolidated sample patches
- Testing guides
- Architecture and operations documentation
- Security control catalog
- Troubleshooting guide
- CSV schemas and prompt templates

## Fast start

1. Extract the ZIP.
2. Open the extracted repository root in IntelliJ IDEA.
3. Open GitHub Copilot Agent Mode.
4. Run `bin\run-agent.bat`.
5. Select a dynamically discovered project and choose `analysis`. The batch scanner scans only that project’s `src` folder and writes a CSV under `.github\output\<project>`.
6. Run `bin\run-agent.bat` again and choose `remediation` to generate the GitHub Copilot remediation prompt.

## Important limitation

The local source scanner is heuristic and does not replace an official Veracode platform scan. Every generated row is marked for manual validation. Remediation remains a GitHub Copilot Agent Mode workflow because Copilot does not expose a supported batch command for automatic prompt execution.
