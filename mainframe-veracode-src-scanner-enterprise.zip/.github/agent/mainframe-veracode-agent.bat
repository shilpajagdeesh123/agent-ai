@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0..\.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "PROJECT=%~1"

if "%PROJECT%"=="" (
  echo ERROR: Project name or project path is required.
  echo Usage: .github\agent\mainframe-veracode-agent.bat ^<project-name^>
  exit /b 1
)

if exist "%PROJECT%\src\" (
  for %%I in ("%PROJECT%") do set "PROJECT_PATH=%%~fI"
) else (
  set "PROJECT_PATH=%ROOT%\%PROJECT%"
)

if not exist "%PROJECT_PATH%\src\" (
  echo ERROR: src folder not found under "%PROJECT_PATH%".
  exit /b 2
)

for %%I in ("%PROJECT_PATH%") do set "PROJECT_NAME=%%~nxI"
for /f %%D in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set "SCAN_DATE=%%D"
set "OUTPUT_DIR=%ROOT%\.github\output\%PROJECT_NAME%"
set "OUTPUT_FILE=%OUTPUT_DIR%\mainframe-veracode-agent-findings-%SCAN_DATE%.csv"

if exist "%OUTPUT_FILE%" (
  for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format HHmmss"') do set "STAMP=%%T"
  set "OUTPUT_FILE=%OUTPUT_DIR%\mainframe-veracode-agent-findings-%SCAN_DATE%-!STAMP!.csv"
)

powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0mainframe-veracode-scanner.ps1" -ProjectPath "%PROJECT_PATH%" -OutputFile "%OUTPUT_FILE%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo ERROR: Source scan failed with exit code %RC%.
  exit /b %RC%
)

echo.
echo Scan completed successfully.
exit /b 0
