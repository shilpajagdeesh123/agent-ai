param(
    [Parameter(Mandatory=$true)][string]$ProjectPath,
    [Parameter(Mandatory=$true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
$project = (Resolve-Path $ProjectPath).Path
$src = Join-Path $project 'src'
if (-not (Test-Path $src -PathType Container)) { throw "src folder not found: $src" }

$projectName = Split-Path $project -Leaf
$scanDate = Get-Date -Format 'yyyy-MM-dd'
$idDate = Get-Date -Format 'yyyyMMdd'

$rules = @(
    @{CWE=89;  Name='SQL Injection'; Severity='Critical'; Regex='(?i)EXECUTE\s+IMMEDIATE|PREPARE\s+.+\s+FROM|STRING\s+.+SQL|DYNAMIC\s+SQL'; Sink='Dynamic SQL'; Fix='Replace dynamic SQL construction with static SQL and host variables. Validate any unavoidable dynamic identifiers against a strict allow-list.'},
    @{CWE=117; Name='Improper Output Neutralization for Logs'; Severity='High'; Regex='(?i)\bDISPLAY\b|\bWRITE\b.*LOG|AUDIT|LOGGER|LOG-MESSAGE'; Sink='Log output'; Fix='Neutralize CR, LF, and other control characters before logging. Prefer fixed-format or structured audit fields.'},
    @{CWE=113; Name='CRLF Injection'; Severity='High'; Regex='(?i)HTTPHEADER|WRITE\s+HTTP|WEB\s+SEND|CONTENT-TYPE|LOCATION\s*:'; Sink='HTTP response/header'; Fix='Reject or encode carriage-return and line-feed characters before building HTTP headers or responses.'},
    @{CWE=79;  Name='Cross-Site Scripting'; Severity='High'; Regex='(?i)<HTML|<SCRIPT|</|WRITE\s+HTTP|WEB\s+SEND|HTML-'; Sink='HTML response'; Fix='Apply context-aware HTML encoding to untrusted values before inserting them into generated markup.'},
    @{CWE=78;  Name='OS Command Injection'; Severity='Critical'; Regex='(?i)BPXWDYN|ADDRESS\s+(UNIX|TSO)|IKJEFT01|SYSTSIN|CALL\s+["'']SYSTEM'; Sink='Command execution'; Fix='Use fixed commands and strict parameter mapping. Never concatenate untrusted data into shell, TSO, or USS commands.'},
    @{CWE=798; Name='Use of Hard-coded Credentials'; Severity='Critical'; Regex='(?i)(PASSWORD|PASSWD|TOKEN|SECRET|API[-_]?KEY|USERID)\s*(VALUE|PIC|=)?.*["''][^"'']+["'']'; Sink='Embedded credential'; Fix='Remove credentials from source and retrieve them from an approved external secret or RACF-managed mechanism.'},
    @{CWE=22;  Name='Path Traversal'; Severity='High'; Regex='(?i)PATH|FILENAME|FILE-NAME|DSNAME|DATASET-NAME|BPXWDYN'; Sink='File or dataset path'; Fix='Map external values to fixed approved paths or dataset names and reject traversal characters and unexpected qualifiers.'},
    @{CWE=20;  Name='Improper Input Validation'; Severity='Medium'; Regex='(?i)\bACCEPT\b|RECEIVE\s+MAP|RECEIVE\s+INTO|GET\s+CONTAINER|MQGET|COMMAREA'; Sink='External input'; Fix='Apply length, type, range, and allow-list validation immediately after input is received and fail closed.'},
    @{CWE=200; Name='Exposure of Sensitive Information'; Severity='High'; Regex='(?i)SSN|AADHAAR|ACCOUNT[- ]?NUMBER|CARD[- ]?NUMBER|PASSWORD|SECRET|TOKEN'; Sink='Sensitive data handling'; Fix='Mask sensitive values in logs and responses and limit disclosure to the minimum required fields.'},
    @{CWE=190; Name='Integer Overflow or Wraparound'; Severity='Medium'; Regex='(?i)\b(COMPUTE|ADD|SUBTRACT|MULTIPLY|DIVIDE)\b(?!.*ON\s+SIZE\s+ERROR)'; Sink='Arithmetic operation'; Fix='Validate numeric ranges and use ON SIZE ERROR for arithmetic that can exceed the target field.'}
)

$extensions = '*.cbl','*.cob','*.cobol','*.cpy','*.copy','*.jcl','*.proc','*.rexx','*.rex','*.pli','*.pl1','*.easy','*.ez'
$files = Get-ChildItem -Path $src -Recurse -File -Include $extensions
$rows = New-Object System.Collections.Generic.List[object]
$sequenceByProgram = @{}

foreach ($file in $files) {
    $lineNo = 0
    Get-Content -LiteralPath $file.FullName | ForEach-Object {
        $lineNo++
        $line = $_
        foreach ($rule in $rules) {
            if ($line -match $rule.Regex) {
                $program = [IO.Path]::GetFileNameWithoutExtension($file.Name).ToUpperInvariant()
                if (-not $sequenceByProgram.ContainsKey($program)) { $sequenceByProgram[$program] = 0 }
                $sequenceByProgram[$program]++
                $findingId = '{0}-{1}-{2:D3}' -f $idDate,$program,$sequenceByProgram[$program]
                $relative = $file.FullName.Substring($project.Length).TrimStart('\','/') -replace '\\','/'
                $snippet = $line.Trim()
                if ($snippet.Length -gt 240) { $snippet = $snippet.Substring(0,240) }
                $rows.Add([pscustomobject]@{
                    'Analysis Sequence'=$rows.Count+1
                    'Application Name'=$projectName
                    'Application Version'='source-scan'
                    'Scan Name'="$projectName-src-static-scan"
                    'Scan Date'=$scanDate
                    'Finding ID'=$findingId
                    'CWE ID'=$rule.CWE
                    'CWE Name'=$rule.Name
                    'Severity'=$rule.Severity
                    'Policy Status'='Review'
                    'Finding Status'='Potential'
                    'Module Name'=$program
                    'Program Name'=$program
                    'File Name'="$projectName/$relative"
                    'Paragraph'=''
                    'Section'=''
                    'Line Number'=$lineNo
                    'Source Type'='Source pattern scan'
                    'Source Variable'=''
                    'Sink Type'=$rule.Sink
                    'Sink Statement'=$snippet
                    'Data Flow Summary'='Pattern detected in source. Confirm whether externally controlled data can reach this statement.'
                    'Existing Validation'='Not established by batch scan'
                    'Existing Sanitization'='Not established by batch scan'
                    'Compensating Control'='Not established by batch scan'
                    'Classification'='Requires Manual Review'
                    'Confidence'='Medium'
                    'Exploitability'='Requires source-to-sink validation'
                    'Business Impact'='Potential security weakness requiring validation.'
                    'Root Cause'='Security-sensitive construct detected by static pattern matching.'
                    'Recommended Fix'=$rule.Fix
                    'Original Code'=$snippet
                    'Secure Code'='See Recommended Fix and validate in program context.'
                    'Regression Risk'='Medium'
                    'Affected Programs'=$program
                    'Affected Copybooks'=''
                    'Test Recommendations'='Add positive, negative, malformed, boundary, regression, and security rescan tests.'
                    'Manual Validation Required'='Yes'
                    'Mitigation Required'='To be determined'
                    'Ready for Rescan'='No'
                    'Analysis Status'='Potential finding generated'
                    'Analysis Notes'='Generated from project src only. This is a local heuristic scan and is not an official Veracode platform result.'
                })
            }
        }
    }
}

$outDir = Split-Path $OutputFile -Parent
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
if ($rows.Count -eq 0) {
    $headers = @('Analysis Sequence','Application Name','Application Version','Scan Name','Scan Date','Finding ID','CWE ID','CWE Name','Severity','Policy Status','Finding Status','Module Name','Program Name','File Name','Paragraph','Section','Line Number','Source Type','Source Variable','Sink Type','Sink Statement','Data Flow Summary','Existing Validation','Existing Sanitization','Compensating Control','Classification','Confidence','Exploitability','Business Impact','Root Cause','Recommended Fix','Original Code','Secure Code','Regression Risk','Affected Programs','Affected Copybooks','Test Recommendations','Manual Validation Required','Mitigation Required','Ready for Rescan','Analysis Status','Analysis Notes')
    ('"' + ($headers -join '","') + '"') | Set-Content -LiteralPath $OutputFile -Encoding UTF8
} else {
    $rows | Export-Csv -LiteralPath $OutputFile -NoTypeInformation -Encoding UTF8
}

Write-Host "Scanned source files : $($files.Count)"
Write-Host "Potential findings   : $($rows.Count)"
Write-Host "Output               : $OutputFile"
