
    # payment-system

    Multi-program COBOL application used to exercise source security analysis and remediation workflows.

    ## Programs

    - PAYMENT
- PAYLOG
- PAYFILE
- PAYVAL
- PAYBATCH

    ## Reports


    ## Run

    `bin\run-agent.bat payment-system analysis`

    `bin\run-agent.bat payment-system remediation`
