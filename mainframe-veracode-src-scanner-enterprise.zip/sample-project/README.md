
    # sample-project

    Multi-program COBOL application used to exercise source security analysis and remediation workflows.

    ## Programs

    - CUSTOMER
- CUSTLOG
- CUSTFILE
- CUSTVAL
- CUSTBATCH

    ## Reports


    ## Run

    `bin\run-agent.bat sample-project analysis`

    `bin\run-agent.bat sample-project remediation`
