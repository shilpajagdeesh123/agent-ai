
# Solution Architecture

The solution separates orchestration, analysis knowledge, remediation knowledge, application source, Veracode inputs, and generated artifacts.

## Layers

1. Repository routing through `AGENTS.md`
2. Agent behavior under `.github/agent`
3. Domain execution detail under `.github/SKILL`
4. Application source under project folders
5. Project source code under `<project>/src`
6. Generated output under `.github/output`
7. Human invocation through GitHub Copilot Agent Mode
8. Launcher scripts under `bin`

## Design goals

- Deterministic scope
- Auditability
- Future format compatibility
- Safe remediation
- Project isolation
- Reversible patches
- Mainframe semantic preservation
