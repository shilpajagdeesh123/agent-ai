# Data Flow

The user runs `bin\run-agent.bat`, selects a dynamically discovered repository project, and chooses analysis. The batch launcher invokes `.github\agent\mainframe-veracode-agent.bat`, which scans only `<project>\src` through the PowerShell scanning engine. Potential CWE-aligned findings are written to `.github\output\<project>`. The remediation workflow reads the latest CSV, validates findings against current source, and prepares consolidated patches through GitHub Copilot Agent Mode.
