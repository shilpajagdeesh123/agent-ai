
# Enterprise Mainframe Veracode Repository Instructions

This repository provides production-grade GitHub Copilot Agent definitions, specialized skills, automation launchers, sample applications, sample Veracode reports, test data, reference patches, and operating documentation.

## Mandatory routing

For analysis work read, in this exact order:

1. `AGENTS.md`
2. `.github/agent/mainframe-veracode-agent.md`
3. `.github/SKILL/mainframe-veracode-skill.md`
4. Project-specific source and report files

For remediation work read, in this exact order:

1. `AGENTS.md`
2. `.github/agent/mainframe-veracode-remediation-agent.md`
3. `.github/SKILL/mainframe-veracode-remediation-skill.md`
4. Latest project-specific analysis CSV
5. Current project source

## Repository boundaries

- Shared agents, skills, prompts, templates, and generated output live only at repository root.
- Individual applications must not contain duplicate `.github`, `AGENTS.md`, or agent files.
- Every operation must be limited to the project explicitly named by the user.
- Output from one project must never be mixed with another project.

## Project-specific output

Analysis:

`.github/output/<PROJECT_NAME>/mainframe-veracode-agent-findings-<YYYY-MM-DD>.csv`

Remediation:

`.github/output/remediation/remediation-report-<PROJECT_NAME>-<YYYY-MM-DD>.md`

`.github/output/remediation/remediation-summary-<PROJECT_NAME>-<YYYY-MM-DD>.csv`

`.github/output/remediation/remediation-log-<PROJECT_NAME>-<YYYY-MM-DD>.txt`

Patches:

`.github/output/remediation/remediation-patches/<PROJECT_NAME>/<SOURCE-FILE>.patch`

## Finding identifiers

Generate internal IDs as:

`<YYYYMMDD>-<PROGRAM-NAME>-<SEQUENCE>`

Example:

`20260719-CUSTOMER-001`

Preserve the original Veracode identifier in `Analysis Notes`.

## Patch policy

- Generate exactly one patch per affected source file.
- Combine all compatible eligible fixes for that file into the same unified diff.
- Do not modify application source unless the user explicitly requests direct application.
- Every remediation summary row for the same file must reference the same patch path.

## Supported applications

- `sample-project`
- `payment-system`

## Supported launcher commands

`bin\run-agent.bat sample-project analysis`

`bin\run-agent.bat sample-project remediation`

`bin\run-agent.bat payment-system analysis`

`bin\run-agent.bat payment-system remediation`
