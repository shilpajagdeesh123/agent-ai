
# Mainframe Veracode Enterprise Deliverable

This package is a complete reference implementation for Veracode finding analysis and safe remediation of COBOL and related mainframe technologies using GitHub Copilot Agent Mode.

## Included

- Production analysis agent
- Production remediation agent
- Dedicated analysis and remediation skills
- Windows batch launchers
- PowerShell launcher
- Shell launcher
- Two multi-program COBOL applications
- Copybooks, JCL, and REXX utilities
- Sample Veracode CSV, JSON, XML, and SARIF reports
- Sample generated findings
- Consolidated sample patches
- Testing guides
- Architecture and operations documentation
- Security control catalog
- Troubleshooting guide
- CSV schemas and prompt templates

## Fast start

1. Extract the ZIP.
2. Open the extracted repository root in IntelliJ IDEA.
3. Open GitHub Copilot Agent Mode.
4. Run:

`bin\run-agent.bat sample-project analysis`

5. Copy the displayed prompt into Copilot Agent Mode.
6. After analysis, run:

`bin\run-agent.bat sample-project remediation`

## Important limitation

The launcher validates folders, creates output locations, archives previous results, builds the exact prompt, and copies the prompt to the Windows clipboard when available. GitHub Copilot Agent Mode does not expose a supported local command-line interface that a batch file can use to submit and execute the prompt automatically.
