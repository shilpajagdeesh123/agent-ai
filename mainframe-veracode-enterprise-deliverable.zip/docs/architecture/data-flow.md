
# Data Flow

Veracode reports enter through the selected project's `veracode` directory. The analysis agent normalizes findings, locates source, traces data, evaluates controls, and writes one row per finding. The remediation agent reads the latest valid analysis CSV, validates current source, groups eligible findings by file, and creates one consolidated unified diff per source file.
