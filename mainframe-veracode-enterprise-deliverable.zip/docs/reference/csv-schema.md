# CSV Schema

See `.github/templates/analysis-header.csv` and `.github/templates/remediation-header.csv`.
