
# Report Format Reference

CSV is best for tabular ingestion. JSON is useful for nested metadata. XML remains common for legacy integrations. SARIF supports standardized tool results, rules, locations, and code flows. The analysis agent preserves unsupported fields in notes and never drops a finding only because a future schema field is unknown.
