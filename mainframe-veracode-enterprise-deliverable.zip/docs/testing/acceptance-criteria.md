
# Acceptance Criteria

- All supplied findings produce analysis rows.
- Internal IDs follow the date-program-sequence format.
- Original IDs remain in notes.
- Only the selected project is accessed.
- Remediation processes eligible severities only.
- Exactly one patch is created per affected source file.
- Patch files are stored under the selected project name.
- Direct source modification does not occur.
