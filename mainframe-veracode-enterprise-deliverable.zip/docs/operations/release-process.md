
# Release Process

- Review agent and skill changes.
- Validate both sample applications.
- Validate all report formats.
- Confirm CSV schemas.
- Run analysis and remediation smoke tests.
- Check project isolation.
- Confirm no direct source modification.
- Create versioned ZIP and checksum.
