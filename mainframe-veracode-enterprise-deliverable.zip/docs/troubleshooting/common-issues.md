
# Common Issues

## Agent takes a long time

Limit the prompt to one project, keep reports local, avoid asking for repository-wide general review, and use the launcher to provide a deterministic prompt.

## Agent scans unrelated files

Confirm `AGENTS.md` is at repository root and repeat the project name in the prompt.

## Output mixed between projects

Verify the output path contains the selected project name and reject any cross-project artifact.

## Duplicate patch files

The remediation agent must group by exact source file before generating diffs.
