
# CWE Playbook

The agents include playbooks for SQL injection, log injection, CRLF injection, XSS, input validation, path traversal, command injection, hardcoded credentials, sensitive data exposure, resource exhaustion, bounds errors, integer overflow, race conditions, and permission assignment.
