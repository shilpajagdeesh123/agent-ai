
    # sample-project

    Multi-program COBOL application used to exercise Veracode analysis and remediation workflows.

    ## Programs

    - CUSTOMER
- CUSTLOG
- CUSTFILE
- CUSTVAL
- CUSTBATCH

    ## Reports

    - `veracode/findings.csv`
    - `veracode/findings.json`
    - `veracode/findings.xml`
    - `veracode/findings.sarif`

    ## Run

    `bin\run-agent.bat sample-project analysis`

    `bin\run-agent.bat sample-project remediation`
