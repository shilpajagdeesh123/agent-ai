
# sample-project Application Overview

The application demonstrates batch and online mainframe patterns, request copybooks, dynamic SQL, audit output, CICS resource access, bounds-sensitive reference modification, JCL execution, and REXX invocation.
