
/* REXX */
say 'Starting sample-project test execution'
address tso "ALLOC FI(INPUT) DA('SAMPLE.INPUT') SHR REUSE"
address tso "CALL 'SAMPLE.LOADLIB(CUSTOMER)'"
say 'Return code:' rc
exit rc
