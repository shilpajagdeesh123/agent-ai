       IDENTIFICATION DIVISION.
       PROGRAM-ID. CUSTFILE.
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. IBM-Z.
       OBJECT-COMPUTER. IBM-Z.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-RETURN-CODE              PIC S9(9) COMP VALUE 0.
       01  WS-SQLCODE                  PIC S9(9) COMP VALUE 0.
       01  WS-INDEX                    PIC S9(4) COMP VALUE 0.
       01  WS-VALID-FLAG               PIC X VALUE 'N'.
       01  WS-SQL-TEXT                 PIC X(1000).
       01  WS-LOG-TEXT                 PIC X(512).
       01  WS-RESOURCE-NAME            PIC X(44).
       01  WS-TEMP                     PIC X(256).
       COPY CUSTOMER-REQUEST.
       PROCEDURE DIVISION.
       0000-MAIN.
           PERFORM 0100-INITIALIZE
           PERFORM 0200-VALIDATE-REQUEST
           IF WS-VALID-FLAG = 'Y'
              PERFORM 1000-PROCESS
           ELSE
              PERFORM 9000-ERROR
           END-IF
           PERFORM 9900-FINALIZE
           GOBACK.

       0100-INITIALIZE.
           MOVE 0 TO WS-RETURN-CODE WS-SQLCODE
           MOVE 'N' TO WS-VALID-FLAG
           MOVE SPACES TO WS-SQL-TEXT WS-LOG-TEXT
                          WS-RESOURCE-NAME WS-TEMP.

       0200-VALIDATE-REQUEST.
           IF REQUEST-ID NOT = SPACES
              MOVE 'Y' TO WS-VALID-FLAG
           END-IF.

       1000-PROCESS.
           MOVE REQUEST-RESOURCE TO WS-RESOURCE-NAME
           EXEC CICS READ
             FILE(WS-RESOURCE-NAME)
             INTO(WS-TEMP)
             RIDFLD(REQUEST-ID)
             RESP(WS-RETURN-CODE)
           END-EXEC.

       2001-BUSINESS-STEP-01.
           IF WS-RETURN-CODE = 1
              MOVE 'STEP-01-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-01-REVIEW' TO WS-TEMP
           END-IF
           ADD 1 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2002-BUSINESS-STEP-02.
           IF WS-RETURN-CODE = 2
              MOVE 'STEP-02-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-02-REVIEW' TO WS-TEMP
           END-IF
           ADD 2 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2003-BUSINESS-STEP-03.
           IF WS-RETURN-CODE = 3
              MOVE 'STEP-03-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-03-REVIEW' TO WS-TEMP
           END-IF
           ADD 3 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2004-BUSINESS-STEP-04.
           IF WS-RETURN-CODE = 0
              MOVE 'STEP-04-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-04-REVIEW' TO WS-TEMP
           END-IF
           ADD 4 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2005-BUSINESS-STEP-05.
           IF WS-RETURN-CODE = 1
              MOVE 'STEP-05-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-05-REVIEW' TO WS-TEMP
           END-IF
           ADD 5 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2006-BUSINESS-STEP-06.
           IF WS-RETURN-CODE = 2
              MOVE 'STEP-06-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-06-REVIEW' TO WS-TEMP
           END-IF
           ADD 6 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2007-BUSINESS-STEP-07.
           IF WS-RETURN-CODE = 3
              MOVE 'STEP-07-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-07-REVIEW' TO WS-TEMP
           END-IF
           ADD 7 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2008-BUSINESS-STEP-08.
           IF WS-RETURN-CODE = 0
              MOVE 'STEP-08-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-08-REVIEW' TO WS-TEMP
           END-IF
           ADD 8 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2009-BUSINESS-STEP-09.
           IF WS-RETURN-CODE = 1
              MOVE 'STEP-09-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-09-REVIEW' TO WS-TEMP
           END-IF
           ADD 9 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2010-BUSINESS-STEP-10.
           IF WS-RETURN-CODE = 2
              MOVE 'STEP-10-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-10-REVIEW' TO WS-TEMP
           END-IF
           ADD 10 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2011-BUSINESS-STEP-11.
           IF WS-RETURN-CODE = 3
              MOVE 'STEP-11-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-11-REVIEW' TO WS-TEMP
           END-IF
           ADD 11 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2012-BUSINESS-STEP-12.
           IF WS-RETURN-CODE = 0
              MOVE 'STEP-12-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-12-REVIEW' TO WS-TEMP
           END-IF
           ADD 12 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2013-BUSINESS-STEP-13.
           IF WS-RETURN-CODE = 1
              MOVE 'STEP-13-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-13-REVIEW' TO WS-TEMP
           END-IF
           ADD 13 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2014-BUSINESS-STEP-14.
           IF WS-RETURN-CODE = 2
              MOVE 'STEP-14-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-14-REVIEW' TO WS-TEMP
           END-IF
           ADD 14 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2015-BUSINESS-STEP-15.
           IF WS-RETURN-CODE = 3
              MOVE 'STEP-15-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-15-REVIEW' TO WS-TEMP
           END-IF
           ADD 15 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2016-BUSINESS-STEP-16.
           IF WS-RETURN-CODE = 0
              MOVE 'STEP-16-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-16-REVIEW' TO WS-TEMP
           END-IF
           ADD 16 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2017-BUSINESS-STEP-17.
           IF WS-RETURN-CODE = 1
              MOVE 'STEP-17-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-17-REVIEW' TO WS-TEMP
           END-IF
           ADD 17 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       2018-BUSINESS-STEP-18.
           IF WS-RETURN-CODE = 2
              MOVE 'STEP-18-OK' TO WS-TEMP
           ELSE
              MOVE 'STEP-18-REVIEW' TO WS-TEMP
           END-IF
           ADD 18 TO WS-RETURN-CODE
             ON SIZE ERROR
                MOVE 12 TO WS-RETURN-CODE
           END-ADD.

       9000-ERROR.
           MOVE 8 TO WS-RETURN-CODE
           DISPLAY 'REQUEST VALIDATION FAILED'.

       9900-FINALIZE.
           MOVE WS-RETURN-CODE TO RETURN-CODE.
