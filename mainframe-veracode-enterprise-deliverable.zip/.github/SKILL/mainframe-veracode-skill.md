# Mainframe Veracode Analysis Skill

## Purpose

Detailed execution method for deterministic analysis of Veracode findings in COBOL and related mainframe applications.

## Required output columns

1. `Analysis Sequence`
2. `Application Name`
3. `Application Version`
4. `Scan Name`
5. `Scan Date`
6. `Finding ID`
7. `CWE ID`
8. `CWE Name`
9. `Severity`
10. `Policy Status`
11. `Finding Status`
12. `Module Name`
13. `Program Name`
14. `File Name`
15. `Paragraph`
16. `Section`
17. `Line Number`
18. `Source Type`
19. `Source Variable`
20. `Sink Type`
21. `Sink Statement`
22. `Data Flow Summary`
23. `Existing Validation`
24. `Existing Sanitization`
25. `Compensating Control`
26. `Classification`
27. `Confidence`
28. `Exploitability`
29. `Business Impact`
30. `Root Cause`
31. `Recommended Fix`
32. `Original Code`
33. `Secure Code`
34. `Regression Risk`
35. `Affected Programs`
36. `Affected Copybooks`
37. `Test Recommendations`
38. `Manual Validation Required`
39. `Mitigation Required`
40. `Ready for Rescan`
41. `Analysis Status`
42. `Analysis Notes`

## Parsing matrix

### CSV

- Use header aliases, quoted fields, and RFC 4180 parsing.
- Retain the original record identifier.
- Record parsing limitations instead of dropping the finding.

### JSON

- Traverse nested findings, flaws, modules, locations, and custom metadata.
- Retain the original record identifier.
- Record parsing limitations instead of dropping the finding.

### XML

- Handle namespaces and preserve unrecognized elements.
- Retain the original record identifier.
- Record parsing limitations instead of dropping the finding.

### SARIF

- Read runs, rules, results, locations, codeFlows, and properties.
- Retain the original record identifier.
- Record parsing limitations instead of dropping the finding.

## Standard source-to-sink workflow

1. Identify the external, privileged, or sensitive source.
2. Locate assignments and transformations.
3. Follow calls and return values.
4. Expand copybook fields and aliases.
5. Review REDEFINES and reference modification.
6. Review table indexes and lengths.
7. Identify the exact sink.
8. Determine whether validation dominates the sink.
9. Determine whether sanitization matches the sink context.
10. Check authorization and operational controls.
11. Assess runtime reachability.
12. Classify and document confidence.

## Skill rule AS-001: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-002: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-003: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-004: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-005: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-006: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-007: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-008: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-009: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-010: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-011: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-012: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-013: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-014: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-015: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-016: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-017: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-018: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-019: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-020: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-021: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-022: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-023: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-024: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-025: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-026: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-027: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-028: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-029: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-030: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-031: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-032: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-033: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-034: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-035: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-036: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-037: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-038: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-039: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-040: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-041: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-042: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-043: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-044: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-045: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-046: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-047: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-048: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-049: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-050: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-051: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-052: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-053: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-054: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-055: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-056: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-057: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-058: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-059: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-060: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-061: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-062: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-063: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-064: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-065: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-066: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-067: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-068: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-069: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-070: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-071: COBOL analysis

- Scope: COBOL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-072: DB2 analysis

- Scope: DB2 evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-073: CICS analysis

- Scope: CICS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-074: IMS analysis

- Scope: IMS evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-075: VSAM analysis

- Scope: VSAM evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-076: MQ analysis

- Scope: MQ evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-077: JCL analysis

- Scope: JCL evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-078: REXX analysis

- Scope: REXX evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-079: Copybook analysis

- Scope: Copybook evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## Skill rule AS-080: Batch analysis

- Scope: Batch evidence relevant to a supplied Veracode finding.
- Inspect declarations, data movement, validation, error paths, and downstream sinks.
- Track values across paragraphs, sections, programs, copybooks, channels, files, and messages as applicable.
- Record observed controls separately from inferred controls.
- Prefer source evidence over naming conventions.
- Treat missing runtime configuration as a manual-review dependency.
- Produce a classification, confidence, exploitability assessment, business impact, root cause, fix direction, and tests.

## CWE decision tables

### CWE-89 SQL Injection

- Indicators: dynamic SQL, EXECUTE IMMEDIATE, concatenated predicates.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: static SQL and host variables.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-117 Log Injection

- Indicators: DISPLAY, audit records, WTO, logger calls.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: control-character neutralization and structured fields.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-113 CRLF Injection

- Indicators: HTTP headers, CICS web support, generated response text.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: reject or encode CR and LF.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-79 Cross-Site Scripting

- Indicators: HTML assembled by COBOL or CICS web programs.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: context-aware output encoding.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-20 Improper Input Validation

- Indicators: transaction fields, COMMAREA, MQ payloads.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: allow-list, length, range, and format checks.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-22 Path Traversal

- Indicators: dataset, USS path, file name, DD override.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: fixed mapping and canonical validation.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-78 OS Command Injection

- Indicators: BPXWDYN, shell, REXX, USS command construction.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: fixed commands and strict parameter mapping.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-798 Hardcoded Credentials

- Indicators: passwords, tokens, keys, RACF IDs.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: external secret management.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-200 Sensitive Data Exposure

- Indicators: logs, reports, MQ, files, screens.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: masking and least disclosure.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-400 Resource Exhaustion

- Indicators: unbounded loops, large OCCURS, message sizes.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: limits and defensive checks.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-125 Out-of-Bounds Read

- Indicators: reference modification, indexes, variable lengths.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: bounds validation.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-787 Out-of-Bounds Write

- Indicators: MOVE, STRING, table indexes.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: target length and index validation.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-190 Integer Overflow

- Indicators: COMP, COMP-3, arithmetic and conversions.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: range validation and ON SIZE ERROR.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-362 Race Condition

- Indicators: shared files, queues, temporary datasets.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: serialization and locking.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.

### CWE-732 Incorrect Permission Assignment

- Indicators: dataset allocation, CICS resources, RACF profiles.
- True Positive evidence: controllable or sensitive data reaches the sink without a complete context-appropriate control.
- False Positive evidence: the reported path is provably unreachable or the value is constant and immutable.
- Mitigation evidence: a control fully constrains or neutralizes the value before every reachable sink.
- Fix direction: least privilege.
- Tests: valid input, invalid input, malicious input, boundary input, regression behavior, and rescan.
