# Mainframe Veracode Remediation Skill

## Purpose

Detailed method for generating safe, consolidated, reviewable patches from approved findings.

## Required remediation summary columns

1. `Remediation Sequence`
2. `Finding ID`
3. `Severity`
4. `CWE ID`
5. `CWE Name`
6. `Application Name`
7. `Program Name`
8. `File Name`
9. `Line Number`
10. `Classification`
11. `Eligibility`
12. `Remediation Status`
13. `Source Validation Status`
14. `Patch Generated`
15. `Patch File`
16. `Root Cause`
17. `Remediation Summary`
18. `Regression Risk`
19. `Developer Review Required`
20. `Manual Decision Required`
21. `Ready for Build`
22. `Ready for Veracode Rescan`
23. `Test Summary`
24. `Skip or Failure Reason`
25. `Notes`

## Patch construction algorithm

1. Read and validate the selected project's latest findings CSV.
2. Filter eligible severities and classifications.
3. Locate current source files.
4. Validate original code against current code.
5. Group rows by exact source file.
6. Sort each group by line and paragraph.
7. Build an in-memory working copy.
8. Apply compatible fixes in source order.
9. Resolve overlaps and eliminate duplicate controls.
10. Generate a single unified diff.
11. Write one patch per source file under the project-specific directory.
12. Write one summary row per finding.
13. Write report and execution log.

## Skill rule RS-001: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-002: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-003: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-004: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-005: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-006: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-007: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-008: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-009: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-010: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-011: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-012: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-013: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-014: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-015: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-016: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-017: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-018: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-019: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-020: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-021: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-022: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-023: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-024: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-025: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-026: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-027: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-028: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-029: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-030: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-031: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-032: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-033: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-034: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-035: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-036: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-037: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-038: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-039: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-040: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-041: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-042: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-043: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-044: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-045: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-046: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-047: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-048: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-049: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-050: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-051: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-052: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-053: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-054: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-055: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-056: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-057: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-058: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-059: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-060: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-061: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-062: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-063: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-064: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-065: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-066: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-067: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-068: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-069: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-070: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-071: COBOL remediation

- Scope: secure remediation for COBOL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-072: DB2 remediation

- Scope: secure remediation for DB2 code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-073: CICS remediation

- Scope: secure remediation for CICS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-074: IMS remediation

- Scope: secure remediation for IMS code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-075: VSAM remediation

- Scope: secure remediation for VSAM code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-076: MQ remediation

- Scope: secure remediation for MQ code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-077: JCL remediation

- Scope: secure remediation for JCL code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-078: REXX remediation

- Scope: secure remediation for REXX code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-079: Copybook remediation

- Scope: secure remediation for Copybook code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Skill rule RS-080: Batch remediation

- Scope: secure remediation for Batch code implicated by an eligible finding.
- Preserve interfaces, layouts, return codes, transaction boundaries, and operational semantics.
- Keep edits minimal and directly tied to the documented root cause.
- Prefer shared validation only when it is clearly safe for all affected paths.
- Do not introduce unsupported syntax or unapproved runtime dependencies.
- Require developer review and targeted regression testing.
- Record any uncertainty as Proposal Only or Requires Manual Review.

## Secure implementation pattern: CWE-89 SQL Injection

- Vulnerable context: dynamic SQL, EXECUTE IMMEDIATE, concatenated predicates.
- Preferred implementation: static SQL and host variables.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-117 Log Injection

- Vulnerable context: DISPLAY, audit records, WTO, logger calls.
- Preferred implementation: control-character neutralization and structured fields.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-113 CRLF Injection

- Vulnerable context: HTTP headers, CICS web support, generated response text.
- Preferred implementation: reject or encode CR and LF.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-79 Cross-Site Scripting

- Vulnerable context: HTML assembled by COBOL or CICS web programs.
- Preferred implementation: context-aware output encoding.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-20 Improper Input Validation

- Vulnerable context: transaction fields, COMMAREA, MQ payloads.
- Preferred implementation: allow-list, length, range, and format checks.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-22 Path Traversal

- Vulnerable context: dataset, USS path, file name, DD override.
- Preferred implementation: fixed mapping and canonical validation.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-78 OS Command Injection

- Vulnerable context: BPXWDYN, shell, REXX, USS command construction.
- Preferred implementation: fixed commands and strict parameter mapping.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-798 Hardcoded Credentials

- Vulnerable context: passwords, tokens, keys, RACF IDs.
- Preferred implementation: external secret management.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-200 Sensitive Data Exposure

- Vulnerable context: logs, reports, MQ, files, screens.
- Preferred implementation: masking and least disclosure.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-400 Resource Exhaustion

- Vulnerable context: unbounded loops, large OCCURS, message sizes.
- Preferred implementation: limits and defensive checks.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-125 Out-of-Bounds Read

- Vulnerable context: reference modification, indexes, variable lengths.
- Preferred implementation: bounds validation.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-787 Out-of-Bounds Write

- Vulnerable context: MOVE, STRING, table indexes.
- Preferred implementation: target length and index validation.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-190 Integer Overflow

- Vulnerable context: COMP, COMP-3, arithmetic and conversions.
- Preferred implementation: range validation and ON SIZE ERROR.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-362 Race Condition

- Vulnerable context: shared files, queues, temporary datasets.
- Preferred implementation: serialization and locking.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.

## Secure implementation pattern: CWE-732 Incorrect Permission Assignment

- Vulnerable context: dataset allocation, CICS resources, RACF profiles.
- Preferred implementation: least privilege.
- Preserve existing error handling and add explicit failure behavior where needed.
- Do not weaken authentication, authorization, audit, or data-integrity controls.
- Add negative tests reproducing the original weakness.
- Require a Veracode rescan after successful build and functional testing.
