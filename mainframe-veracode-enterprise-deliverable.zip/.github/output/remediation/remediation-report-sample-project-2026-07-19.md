# Remediation Report

Project: `sample-project`

## Findings

### 20260719-CUSTOMER-001

- Original ID: VF-1001
- Severity: Critical
- CWE: 89 SQL Injection
- Patch: `.github/output/remediation/remediation-patches/sample-project/customer.cbl.patch`
- Status: Proposal Only
- Developer review required: Yes
- Veracode rescan required: Yes

### 20260719-CUSTLOG-001

- Original ID: VF-1002
- Severity: High
- CWE: 117 Improper Output Neutralization for Logs
- Patch: `.github/output/remediation/remediation-patches/sample-project/custlog.cbl.patch`
- Status: Proposal Only
- Developer review required: Yes
- Veracode rescan required: Yes

### 20260719-CUSTFILE-001

- Original ID: VF-1003
- Severity: High
- CWE: 99 Resource Identifier Injection
- Patch: `.github/output/remediation/remediation-patches/sample-project/custfile.cbl.patch`
- Status: Proposal Only
- Developer review required: Yes
- Veracode rescan required: Yes

### 20260719-CUSTVAL-001

- Original ID: VF-1004
- Severity: High
- CWE: 125 Out-of-Bounds Read
- Patch: `.github/output/remediation/remediation-patches/sample-project/custval.cbl.patch`
- Status: Proposal Only
- Developer review required: Yes
- Veracode rescan required: Yes
