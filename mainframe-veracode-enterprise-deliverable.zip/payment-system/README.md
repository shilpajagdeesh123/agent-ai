
    # payment-system

    Multi-program COBOL application used to exercise Veracode analysis and remediation workflows.

    ## Programs

    - PAYMENT
- PAYLOG
- PAYFILE
- PAYVAL
- PAYBATCH

    ## Reports

    - `veracode/findings.csv`
    - `veracode/findings.json`
    - `veracode/findings.xml`
    - `veracode/findings.sarif`

    ## Run

    `bin\run-agent.bat payment-system analysis`

    `bin\run-agent.bat payment-system remediation`
