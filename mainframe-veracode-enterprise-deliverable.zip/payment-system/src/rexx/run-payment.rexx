
/* REXX */
say 'Starting payment-system test execution'
address tso "ALLOC FI(INPUT) DA('PAYMENT.INPUT') SHR REUSE"
address tso "CALL 'PAYMENT.LOADLIB(PAYMENT)'"
say 'Return code:' rc
exit rc
