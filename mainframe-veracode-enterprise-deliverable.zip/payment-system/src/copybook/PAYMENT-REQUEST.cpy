
01  REQUEST-AREA.
    05  REQUEST-ID                 PIC X(20).
    05  REQUEST-ACCOUNT            PIC X(24).
    05  REQUEST-MESSAGE            PIC X(200).
    05  REQUEST-RESOURCE           PIC X(44).
    05  REQUEST-LENGTH             PIC 9(4).
    05  REQUEST-AMOUNT             PIC S9(9)V99 COMP-3.
    05  REQUEST-REFERENCE          PIC X(50).
    05  REQUEST-CHANNEL            PIC X(16).
