# Repository Agent Instructions

This repository contains shared Mainframe Veracode analysis and remediation agents.

## Agent locations

Analysis agent:

```text
.github/agent/mainframe-veracode-agent.md
```

Remediation agent:

```text
.github/agent/mainframe-veracode-remediation-agent.md
```

Skills:

```text
.github/SKILL/mainframe-veracode-skill.md
.github/SKILL/mainframe-veracode-remediation-skill.md
```

## Execution rules

1. Read this file first.
2. For analysis, read the analysis agent and analysis skill.
3. For remediation, read the remediation agent and remediation skill.
4. Restrict work to the project named in the prompt.
5. Store analysis output under `.github/output/<PROJECT_NAME>/`.
6. Store consolidated patches under:
   `.github/output/remediation/remediation-patches/<PROJECT_NAME>/`.
7. Never duplicate agent files inside individual project folders.
8. Never modify production source directly unless explicitly requested.
9. Generate one patch per affected source file, combining all eligible findings for that file.
10. Generate finding IDs with the execution date prefix.

## Prompts

Analysis:

```text
Execute the mainframe-veracode-agent for project sample-project.
```

Remediation:

```text
Execute the mainframe-veracode-remediation-agent for project sample-project.
```
