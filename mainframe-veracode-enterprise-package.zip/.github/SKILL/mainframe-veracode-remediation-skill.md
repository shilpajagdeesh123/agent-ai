# Mainframe Veracode Remediation Skill

## Purpose

Define safe remediation and consolidated patch-generation rules.

## Input rules

- Use only the selected project's analysis CSV.
- Do not invent findings.
- Preserve one remediation summary row per finding.
- Process Critical and High by default.
- Record skipped findings and reasons.

## Source validation states

Use one:

- Confirmed
- Changed Since Analysis
- Not Found
- Ambiguous
- Not Applicable

Do not generate an automatic patch for `Not Found` or `Ambiguous`.

## Remediation safety

Every fix must preserve:

- Business behavior
- Program interfaces
- Copybook layouts
- Return codes
- SQLCODE and SQLSTATE handling
- Commit and rollback behavior
- CICS RESP and RESP2 handling
- IMS transaction behavior
- VSAM record behavior
- MQ message contracts
- Batch restartability

Avoid:

- Broad refactoring
- Security suppression
- Hardcoded secrets
- Unrelated formatting
- Direct source modification
- Unsupported compiler syntax

## Patch rules

1. One patch per source file.
2. Store under:
   `.github/output/remediation/remediation-patches/<PROJECT_NAME>/`.
3. Name patch using the full source filename plus `.patch`.
4. Example:
   `customer.cbl.patch`.
5. Include all safe eligible fixes for the file.
6. Generate unified diff format.
7. Avoid whitespace-only changes.
8. Preserve original source layout.
9. Record all addressed Finding IDs in the remediation report.
10. Use the same patch path for every related summary row.

## Conflict handling

When findings overlap:

- Merge compatible changes.
- Prefer a single root-cause fix.
- Avoid duplicate validation blocks.
- Do not generate conflicting code.
- Mark unresolved findings `Requires Manual Review`.
- Continue with safe independent fixes.

## Testing

For each finding define:

- Positive test
- Negative test
- Boundary test
- Malformed input test
- Regression test
- Authorization test when applicable
- SQL transaction test when applicable
- Batch restart test when applicable
- CICS or IMS test when applicable
- Veracode rescan requirement

## Common secure patterns

### SQL injection

- Static SQL
- Host variables
- Prepared statements
- Allow-listed identifiers

### Log injection

- Replace or reject CR, LF, tab, ESC, and non-printable controls
- Mask sensitive values
- Preserve audit usefulness

### Resource injection

- External-to-internal allow-list mapping
- Fixed CICS, IMS, VSAM, MQ, or dataset names
- Preserve security and response handling

### Sensitive data

- Mask all but approved characters
- Avoid full values in logs
- Use approved encryption or tokenization services

## Output validation

Before completion verify:

- Every Critical and High finding has a summary row.
- Every skipped finding has a reason.
- Every patch belongs to the selected project.
- Every patch corresponds to a confirmed source file.
- No source file was modified directly.
- No Medium or Low finding was patched unless requested.
- No duplicate patch exists for the same source file.
