# Mainframe Veracode Analysis Skill

## Purpose

Provide detailed implementation rules for the Mainframe Veracode Analysis Agent.

## Intake

For every supplied finding capture:

- Application name and version
- Scan name and date
- Original Veracode finding ID
- CWE ID and name
- Severity
- Policy status
- Finding status
- Module
- Program
- File
- Paragraph
- Section
- Line number
- Source
- Sink
- Data flow
- Existing mitigation
- Veracode recommendation
- Unknown metadata

## Source-to-sink analysis

Trace only code relevant to the finding:

- Entry field
- Copybook field
- Working-storage field
- MOVE
- STRING
- UNSTRING
- INSPECT
- REDEFINES
- OCCURS
- Reference modification
- Caller and callee programs when needed
- DB2 host variables
- CICS channels, containers, COMMAREA, files, queues, and programs
- IMS segments and transaction fields
- VSAM keys and records
- MQ message fields

## Validation review

Evaluate:

- Allow-list validation
- Length validation
- Range validation
- Format validation
- Character validation
- Authorization
- RACF
- CICS security
- DB2 privileges
- Operational controls
- Data masking
- Control-character neutralization

## Classification rules

### True Positive

Use when:

- The path is reachable.
- Input is controllable or sensitive.
- Validation is missing or insufficient.
- The sink behavior is unsafe.

### False Positive

Use only with clear evidence that:

- The path is unreachable, or
- The value is fixed and cannot be influenced, or
- The reported sink is not security-relevant.

### Mitigated by Existing Control

Use when an effective control clearly breaks the risk.

### Requires Manual Review

Use when technical evidence is incomplete or depends on runtime configuration.

### Insufficient Evidence

Use when required source or report data is unavailable.

### Analysis Error

Use for parsing or tooling failure that blocks analysis.

## Mainframe remediation guidance

### SQL injection

- Prefer static SQL.
- Use host variables.
- Use parameter markers.
- Allow-list identifiers that cannot be parameterized.
- Preserve SQLCODE, SQLSTATE, cursors, commits, and rollbacks.

### Log injection and CRLF

- Neutralize CR, LF, tabs, ESC, and non-printable characters.
- Prefer structured logging.
- Avoid logging full sensitive values.

### CICS resource injection

- Map external values to fixed internal resource names.
- Use allow-lists.
- Preserve RESP and RESP2 behavior.

### Bounds and length

- Validate before MOVE, STRING, UNSTRING, or reference modification.
- Validate OCCURS indexes.
- Preserve PIC layout and numeric representation.

## Reporting

- Use the generated date-prefixed Finding ID.
- Preserve the original Veracode ID in notes.
- Keep one row per finding.
- Do not merge different findings into one CSV row.
- Preserve unknown metadata.
