# payment-system Test Guide

Analysis:

```text
Execute the mainframe-veracode-agent for project payment-system.
```

Remediation:

```text
Execute the mainframe-veracode-remediation-agent for project payment-system.
```

Expected patch directory:

```text
.github/output/remediation/remediation-patches/payment-system/
```
