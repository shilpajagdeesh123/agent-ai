# IntelliJ IDEA and GitHub Copilot Guide

1. Extract the ZIP.
2. Open IntelliJ IDEA.
3. Select **File → Open**.
4. Choose the extracted repository root.
5. Open the GitHub Copilot tool window.
6. Select Agent Mode.
7. Ensure the repository root contains `AGENTS.md`.

## Run sample-project analysis

```text
Follow AGENTS.md and execute the mainframe-veracode-agent for project sample-project.
```

## Run sample-project remediation

```text
Follow AGENTS.md and execute the mainframe-veracode-remediation-agent for project sample-project.
```

## Run payment-system analysis

```text
Follow AGENTS.md and execute the mainframe-veracode-agent for project payment-system.
```

## Run payment-system remediation

```text
Follow AGENTS.md and execute the mainframe-veracode-remediation-agent for project payment-system.
```

## Expected output

Analysis:

```text
.github/output/<PROJECT_NAME>/mainframe-veracode-agent-findings-<YYYY-MM-DD>.csv
```

Patches:

```text
.github/output/remediation/remediation-patches/<PROJECT_NAME>/<SOURCE-FILE>.patch
```
