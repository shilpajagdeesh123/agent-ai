# Sample Project

Dummy COBOL customer-search application for agent testing.
