# sample-project Test Guide

Analysis:

```text
Execute the mainframe-veracode-agent for project sample-project.
```

Remediation:

```text
Execute the mainframe-veracode-remediation-agent for project sample-project.
```

Expected patch directory:

```text
.github/output/remediation/remediation-patches/sample-project/
```
