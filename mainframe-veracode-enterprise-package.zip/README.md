# Mainframe Veracode Enterprise Package

This package is designed for IntelliJ IDEA with GitHub Copilot Agent Mode.

## Repository structure

```text
.github/
├── agent/
│   ├── mainframe-veracode-agent.md
│   └── mainframe-veracode-remediation-agent.md
├── SKILL/
│   ├── mainframe-veracode-skill.md
│   └── mainframe-veracode-remediation-skill.md
└── output/
    ├── sample-project/
    ├── payment-system/
    └── remediation/
        └── remediation-patches/
            ├── sample-project/
            └── payment-system/

sample-project/
payment-system/
AGENTS.md
README.md
INTELLIJ-COPILOT-GUIDE.md
```

## Finding ID format

```text
<YYYYMMDD>-<PROGRAM-NAME>-<SEQUENCE>
```

Examples:

```text
20260719-CUSTOMER-001
20260719-CUSTOMER-002
20260719-CUSTOMER-003
```

The original Veracode finding ID must be preserved in `Analysis Notes`.

## Patch generation rule

When one file has multiple eligible findings, generate one consolidated patch.

Example:

```text
.github/output/remediation/remediation-patches/sample-project/customer.cbl.patch
```

The patch must include all safe fixes for eligible findings in `customer.cbl`.

## IntelliJ execution

Open this repository root in IntelliJ IDEA, open GitHub Copilot Agent Mode, and run:

```text
Execute the mainframe-veracode-agent for project sample-project.
```

Then:

```text
Execute the mainframe-veracode-remediation-agent for project sample-project.
```
